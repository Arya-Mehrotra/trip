-- phpMyAdmin SQL Dump
-- version 4.8.3
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: May 11, 2019 at 12:52 PM
-- Server version: 5.7.23
-- PHP Version: 5.6.38

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ecomm`
--

DELIMITER $$
--
-- Procedures
--
DROP PROCEDURE IF EXISTS `result`$$
CREATE DEFINER=`root`@`localhost` PROCEDURE `result` ()  select products.product_name,products.price,products.description,products.product_thumbnail,specific_attribs
	.product_id,specific_attribs.attribute,attribute_value from products inner join specific_attribs 
	on products.id=specific_attribs.product_id where product_id=2$$

DELIMITER ;

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
CREATE TABLE IF NOT EXISTS `admin` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `admin_name` varchar(100) NOT NULL,
  `password` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `admin_name`, `password`) VALUES
(1, 'admin@gmail.com', '5f4dcc3b5aa765d61d8327deb882cf99');

-- --------------------------------------------------------

--
-- Table structure for table `arrivals`
--

DROP TABLE IF EXISTS `arrivals`;
CREATE TABLE IF NOT EXISTS `arrivals` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `category` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `arrivals`
--

INSERT INTO `arrivals` (`id`, `category`) VALUES
(1, 'Womens'),
(2, 'Mens'),
(3, 'Bags'),
(4, 'Footwear');

-- --------------------------------------------------------

--
-- Table structure for table `arrival_products`
--

DROP TABLE IF EXISTS `arrival_products`;
CREATE TABLE IF NOT EXISTS `arrival_products` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(100) DEFAULT NULL,
  `price` varchar(15) DEFAULT NULL,
  `orignal_price` varchar(15) DEFAULT NULL,
  `description` text,
  `thumbnail` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `arrival_products`
--

INSERT INTO `arrival_products` (`id`, `product_name`, `price`, `orignal_price`, `description`, `thumbnail`) VALUES
(1, 'A-line Blasck Skirt', '999', '1100', 'Black Strip Dress for Women', 'w1.jpg'),
(3, 'Anglo Watch', '550', '750', 'Anglo Golden Women\'s watch', 'w6.jpg'),
(4, 'Basic Black Shorts', '1100', '1250', 'Basic Black Shorts For Girls', 'w4.jpg'),
(7, 'Skinny Jeans', '350', '500', 'Black Skin tight Jeans', 'w31.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `attributes`
--

DROP TABLE IF EXISTS `attributes`;
CREATE TABLE IF NOT EXISTS `attributes` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `attrib_name` varchar(50) NOT NULL,
  `sub_cat_id` int(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=29 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `attributes`
--

INSERT INTO `attributes` (`id`, `attrib_name`, `sub_cat_id`) VALUES
(12, 'Brand', 9),
(6, 'Brand', 7),
(8, 'ROM', 7),
(9, 'RAM', 7),
(15, 'OS', 7),
(14, 'Brand', 10),
(16, 'Name', 11),
(17, 'Publication', 11),
(18, 'Writer', 11),
(19, 'Brand', 20),
(20, 'OS', 20),
(21, 'Processor', 20),
(25, 'RAM', 20),
(23, 'Hard Disk', 20),
(24, 'GPU', 20),
(26, 'Brand', 24),
(27, 'Fabric', 24),
(28, 'Brand', 25);

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

DROP TABLE IF EXISTS `brands`;
CREATE TABLE IF NOT EXISTS `brands` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `logo` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `logo`) VALUES
(8, 'download.png'),
(6, 'linkedin.png'),
(3, '80.png'),
(4, 'instagram.png'),
(5, '2.png');

-- --------------------------------------------------------

--
-- Table structure for table `bucket`
--

DROP TABLE IF EXISTS `bucket`;
CREATE TABLE IF NOT EXISTS `bucket` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `product_id` int(15) NOT NULL,
  `quantity` int(15) DEFAULT NULL,
  `price` varchar(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
CREATE TABLE IF NOT EXISTS `category` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `cat_name` varchar(100) NOT NULL,
  `level` int(10) NOT NULL,
  `parentid` int(10) NOT NULL,
  `thumbnail` varchar(200) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`id`, `cat_name`, `level`, `parentid`, `thumbnail`) VALUES
(1, 'Electronics', 0, 0, '01_131_10_2.jpg'),
(2, 'Men', 0, 0, 'tshirt.jpeg'),
(3, 'Women', 0, 0, 'w2.jpg'),
(5, 'Books', 0, 0, 'hfhtml.jpg'),
(7, 'Mobiles', 1, 1, ''),
(9, 'Denim Shirt', 1, 2, ''),
(10, 'Jeans', 1, 2, ''),
(11, 'Programming Books', 1, 5, ''),
(14, 'Hand Bags', 1, 3, ''),
(15, 'Ladies shoes', 1, 3, ''),
(17, 'Robotics', 1, 5, ''),
(18, 'Washing Machine', 1, 1, ''),
(19, 'Psycology', 1, 5, ''),
(20, 'Laptops', 1, 1, ''),
(22, 'Sports', 0, 0, '61Qz1cINR4L__SX425_.jpg'),
(23, 'Cricket Bat', 1, 22, ''),
(24, 'Men\'s Track Pants', 1, 2, ''),
(25, 'Accessories', 1, 2, '');

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE IF NOT EXISTS `products` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(150) NOT NULL,
  `price` varchar(15) DEFAULT NULL,
  `sale_price` varchar(15) DEFAULT NULL,
  `productid` varchar(250) NOT NULL,
  `description` text,
  `tax` varchar(10) DEFAULT NULL,
  `shipping_cost` varchar(10) DEFAULT NULL,
  `product_thumbnail` varchar(250) NOT NULL,
  `product_category` int(15) NOT NULL,
  `new_arrival` int(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`id`, `product_name`, `price`, `sale_price`, `productid`, `description`, `tax`, `shipping_cost`, `product_thumbnail`, `product_category`, `new_arrival`) VALUES
(3, 'Note 6 pro', '11999', NULL, 'Mobmin6p', 'Say hello to Redmi Note 6 Pro - Xiaomi\'s first smartphone that boasts an AI-powered quad-camera. Now enjoy a smart camera experience with the AI Scene Detection feature                                                     ', '12', 'N/A', 'min6pro.jpeg', 7, 0),
(4, 'Zenfone Max Pro 1', '12500', NULL, 'Monasusmpro11', 'Meet the Asus Zenfone Max Pro (M1), whose power-packed features such as the loud speaker and a high-capacity battery, will elevate your smartphone experience to a different level. Its Dual-camera System with Bokeh is bound to make your pictures look beautiful.                                                      ', '12', 'N/A', 'asus.jpeg', 7, 0),
(5, 'Redmi6', '7999', NULL, 'Mobmi6', '  Click away with the Redmi 6 - it is built for photography enthusiasts. It features a 12 MP + 5 MP AI Dual Camera System and the Portrait Mode on the Front Camera                                                    ', '12', 'N/A', 'mi6.jpeg', 7, 0),
(7, 'HP 14q Core i3 7th Gen ', '26490', NULL, 'Laphp14', 'Looking for a compact laptop to do your work or to access entertainment when it\'s time for a break? This HP laptop boasts an Intel Core i3 7th Gen processor, 4 GB of DDR4 RAM                         ', '13', 'N/A', 'hp.jpeg', 20, 0),
(8, 'Acer Aspire 5s', '39990', NULL, 'Lapacer5s', '  Pre-installed Genuine Windows 10 OS                                                    ', '18', 'N/A', 'acer.jpeg', 20, 0),
(10, 'Denim Lingo', '799', '650', 'Dshirtmen121', 'Men Solid Casual Slim Shirt                                                      ', '15', 'N/A', 'denim.jpeg', 9, 1),
(11, 'Reynard Track', '549', '500', 'Trackpantmen101', 'Printed Men Dark Blue, Blue Track Pants                                                      ', '15', 'N/A', 'trackpant.jpeg', 24, 1),
(12, 'MAXX', '139', '', 'Gogglesg121', 'UV Protection, Polarized Aviator Sunglasses                                                    ', '15', '100', 'goggles.jpeg', 25, 1);

-- --------------------------------------------------------

--
-- Table structure for table `result`
--

DROP TABLE IF EXISTS `result`;
CREATE TABLE IF NOT EXISTS `result` (
  `product_name` varchar(150) NOT NULL,
  `price` varchar(15) DEFAULT NULL,
  `description` text,
  `product_thumbnail` varchar(250) NOT NULL,
  `attribute` varchar(100) DEFAULT NULL,
  `attribute_value` varchar(100) DEFAULT NULL,
  `product_id` int(15) NOT NULL,
  `id` int(15) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Dumping data for table `result`
--

INSERT INTO `result` (`product_name`, `price`, `description`, `product_thumbnail`, `attribute`, `attribute_value`, `product_id`, `id`) VALUES
('Redmi6', '7999', '  Click away with the Redmi 6 - it is built for photography enthusiasts. It features a 12 MP + 5 MP AI Dual Camera System and the Portrait Mode on the Front Camera                                                    ', 'mi6.jpeg', 'Brand', 'Xiomi', 5, 40),
('Note 6 pro', '11999', 'Say hello to Redmi Note 6 Pro - Xiaomi\'s first smartphone that boasts an AI-powered quad-camera. Now enjoy a smart camera experience with the AI Scene Detection feature                                                     ', 'min6pro.jpeg', 'Brand', 'Xiomi', 3, 32);

-- --------------------------------------------------------

--
-- Table structure for table `slab`
--

DROP TABLE IF EXISTS `slab`;
CREATE TABLE IF NOT EXISTS `slab` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `slab_name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slab`
--

INSERT INTO `slab` (`id`, `slab_name`) VALUES
(1, 'With In The City'),
(3, 'Outside the City'),
(4, 'Outside the state'),
(5, 'Outside The Country');

-- --------------------------------------------------------

--
-- Table structure for table `slablist`
--

DROP TABLE IF EXISTS `slablist`;
CREATE TABLE IF NOT EXISTS `slablist` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `slab_name` varchar(100) NOT NULL,
  `cost` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slablist`
--

INSERT INTO `slablist` (`id`, `slab_name`, `cost`) VALUES
(1, 'With In The City', '100'),
(2, 'Outside the City', '250'),
(3, 'Outside The Country', '1500'),
(4, 'Outside the state', '1500');

-- --------------------------------------------------------

--
-- Table structure for table `specific_attribs`
--

DROP TABLE IF EXISTS `specific_attribs`;
CREATE TABLE IF NOT EXISTS `specific_attribs` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `attribute` varchar(100) DEFAULT NULL,
  `attribute_value` varchar(100) DEFAULT NULL,
  `product_id` int(15) NOT NULL,
  `cat_id` int(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=60 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `specific_attribs`
--

INSERT INTO `specific_attribs` (`id`, `attribute`, `attribute_value`, `product_id`, `cat_id`) VALUES
(33, 'ROM', '64GB', 3, 7),
(46, 'Processor', 'Core i3', 7, 20),
(45, 'OS', 'DOS', 7, 20),
(47, 'Hard Disk', '1TB', 7, 20),
(36, 'Brand', 'Asus', 4, 7),
(35, 'OS', 'Android', 3, 7),
(34, 'RAM', '4GB', 3, 7),
(40, 'Brand', 'Xiomi', 5, 7),
(38, 'RAM', '6GB', 4, 7),
(32, 'Brand', 'Xiomi', 3, 7),
(31, 'OS', 'Android', 9, 7),
(30, 'RAM', '4GB', 9, 7),
(28, 'Brand', 'Xiomi', 9, 7),
(41, 'ROM', '32GB', 5, 7),
(29, 'ROM', '64GB', 9, 7),
(43, 'OS', 'Android', 5, 7),
(42, 'RAM', '3GB', 5, 7),
(39, 'OS', 'Android', 4, 7),
(37, 'ROM', '64GB', 4, 7),
(48, 'GPU', 'Intel Integrated', 7, 20),
(44, 'Brand', 'HP', 7, 20),
(49, 'RAM', '4GB', 7, 20),
(50, 'Brand', 'Acer', 8, 20),
(51, 'OS', 'Windows 10', 8, 20),
(52, 'Processor', 'Core I5', 8, 20),
(53, 'RAM', '8GB', 8, 20),
(54, 'Hard Disk', '1TB', 8, 20),
(55, 'GPU', 'Intel Integrated', 8, 20),
(56, 'Brand', 'Denim LIngo', 10, 9),
(57, 'Brand', 'Reynard', 11, 24),
(58, 'Fabric', 'Polyster Cotton', 11, 24),
(59, 'Brand', 'Singcoindia', 12, 25);

-- --------------------------------------------------------

--
-- Table structure for table `specific_gallery`
--

DROP TABLE IF EXISTS `specific_gallery`;
CREATE TABLE IF NOT EXISTS `specific_gallery` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `gallery_img` varchar(250) NOT NULL,
  `product_id` int(15) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=31 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `specific_gallery`
--

INSERT INTO `specific_gallery` (`id`, `gallery_img`, `product_id`) VALUES
(1, 'mi2.jpeg', 3),
(2, 'mi3.jpeg', 3),
(3, 'mi4.jpeg', 3),
(4, 'mi6pro1.jpeg', 3),
(5, 'asus1.jpeg', 4),
(6, 'asus2.jpeg', 4),
(7, 'asus3.jpeg', 4),
(8, 'asus4.jpeg', 4),
(9, 'mi61.jpeg', 5),
(10, 'mi62.jpeg', 5),
(11, 'mi63.jpeg', 5),
(12, 'mi64.jpeg', 5),
(13, 'hp1.jpeg', 7),
(14, 'hp2.jpeg', 7),
(15, 'hp3.jpeg', 7),
(16, 'hp4.jpeg', 7),
(17, 'acer1.jpeg', 8),
(18, 'acer2.jpeg', 8),
(19, 'acer3.jpeg', 8),
(20, 'acer4.jpeg', 8),
(21, 'd1.jpeg', 10),
(22, 'd2.jpeg', 10),
(23, 'd3.jpeg', 10),
(24, 'd4.jpeg', 10),
(25, 'track1.jpeg', 11),
(26, 'track2.jpeg', 11),
(27, 'track3.jpeg', 11),
(28, 'track4.jpeg', 11),
(29, 'gog1.jpeg', 12),
(30, 'gog2.jpeg', 12);

-- --------------------------------------------------------

--
-- Table structure for table `stock`
--

DROP TABLE IF EXISTS `stock`;
CREATE TABLE IF NOT EXISTS `stock` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(50) NOT NULL,
  `available_stock` varchar(5) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `stock`
--

INSERT INTO `stock` (`id`, `product_name`, `available_stock`) VALUES
(1, 'Note 6 pro', '100'),
(2, 'Zenfone Max Pro 1', '55'),
(3, 'Redmi6', '150'),
(4, 'HP 14q Core i3 7th Gen ', '54');

-- --------------------------------------------------------

--
-- Table structure for table `tax`
--

DROP TABLE IF EXISTS `tax`;
CREATE TABLE IF NOT EXISTS `tax` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `tax` varchar(10) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `tax`
--

INSERT INTO `tax` (`id`, `tax`) VALUES
(5, '15'),
(6, '18'),
(7, '10');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(250) NOT NULL,
  `email` varchar(150) NOT NULL,
  `address` text NOT NULL,
  `pwd` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `user_name`, `email`, `address`, `pwd`) VALUES
(1, 'Aryan Mehrotra', 'aryan123@gmail.com', 'vashishtpuram', 'ba63ecc2d6330f4ae84ac329ae268cbf'),
(2, 'user2', 'user@gmail.com', 'sec-I alignaj, lucknow, 226024', 'ba5ef51294fea5cb4eadea5306f3ca3b'),
(3, 'user 2', 'user123@gmail.com', 'aliganj,lucknow 226024', 'ba5ef51294fea5cb4eadea5306f3ca3b'),
(4, 'user', 'user123@gmail.com', 'aliganj,lucknow', 'ba5ef51294fea5cb4eadea5306f3ca3b'),
(5, 'user', 'user123@gmail.com', 'aliganj,lucknow', 'ba5ef51294fea5cb4eadea5306f3ca3b'),
(6, 'user 2', 'user123@gmail.com', 'aliganj,lucknow', 'ba5ef51294fea5cb4eadea5306f3ca3b');

-- --------------------------------------------------------

--
-- Table structure for table `variants`
--

DROP TABLE IF EXISTS `variants`;
CREATE TABLE IF NOT EXISTS `variants` (
  `id` int(15) NOT NULL AUTO_INCREMENT,
  `variant_name` varchar(150) NOT NULL,
  `category_id` int(15) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=latin1;

--
-- Dumping data for table `variants`
--

INSERT INTO `variants` (`id`, `variant_name`, `category_id`) VALUES
(1, 'Colors', 7),
(2, 'Color', 9),
(5, 'Size', 9),
(8, 'Color', 18);

-- --------------------------------------------------------

--
-- Table structure for table `variants_details`
--

DROP TABLE IF EXISTS `variants_details`;
CREATE TABLE IF NOT EXISTS `variants_details` (
  `id` int(35) NOT NULL AUTO_INCREMENT,
  `specific_product_id` int(35) NOT NULL,
  `variant_id` int(35) NOT NULL,
  `variant_value` varchar(150) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
